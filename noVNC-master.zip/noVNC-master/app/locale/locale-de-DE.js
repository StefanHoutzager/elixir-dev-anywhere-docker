Language = {
    "Connected (encrypted) to ": "Verbunden mit (verschlüsselt) ",
    "Connected (unencrypted) to ": "Verbunden mit (unverschlüsselt) ",
    "Must set host and port": "Richten Sie Host und Port ein",
    "Disconnect timeout": "Timeout beim trennen",
    "Password is required": "Passwort ist erforderlich",
    "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "'Clipping-Modus' aktiviert, Scrollbalken in 'IE-Vollbildmodus' werden nicht unterstützt",
    "Connecting...": "Verbunden...",
    "Disconnecting...": "Verbindung trennen...",
    "Disconnected": "Verbindung zum Server getrennt",
};
