Language = {
	"Connected (encrypted) to ": "Συνδέθηκε (κρυπτογραφημένα) με το ",
	"Connected (unencrypted) to ": "Συνδέθηκε (μη κρυπτογραφημένα) με το ",
	"Must set host and port": "Πρέπει να οριστεί το όνομα και η πόρτα του διακομιστή",
	"Disconnect timeout": "Παρέλευση χρονικού ορίου αποσύνδεσης",
	"Password is required": "Απαιτείται ο κωδικός",
	"Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "Εφαρμογή λειτουργίας αποκοπής αφού δεν υποστηρίζονται οι λωρίδες κύλισης σε πλήρη οθόνη στον IE",
	"Connecting...": "Συνδέεται...",
	"Disconnecting...": "Aποσυνδέεται...",
	"Disconnected": "Αποσυνδέθηκε",
};
