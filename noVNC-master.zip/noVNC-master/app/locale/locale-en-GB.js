Language = {
    "Connected (encrypted) to ": "Connected (encrypted) to ",
    "Connected (unencrypted) to ": "Connected (unencrypted) to ",
    "Must set host and port": "Must set host and port",
    "Disconnect timeout": "Disconnect timeout",
    "Password is required": "Password is required",
    "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen",
    "Connecting...": "Connecting...",
    "Disconnecting...": "Disconnecting...",
    "Disconnected": "Disconnected",
};
