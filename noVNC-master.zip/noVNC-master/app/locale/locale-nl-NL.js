Language = {
    "Connected (encrypted) to ": "Verbonden (versleuteld) met ",
    "Connected (unencrypted) to ": "Verbonden (onversleuteld) met ",
    "Must set host and port": "Host en poort moeten worden ingesteld",
    "Disconnect timeout": "Timeout tijdens verbreken van verbinding",
    "Password is required": "Wachtwoord is vereist",
    "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "''Clipping mode' ingeschakeld, omdat schuifbalken in volledige-scherm-modus in IE niet worden ondersteund",
    "Connecting...": "Verbinden...",
    "Disconnecting...": "Verbinding verbreken...",
    "Disconnected": "Verbinding verbroken",
};
