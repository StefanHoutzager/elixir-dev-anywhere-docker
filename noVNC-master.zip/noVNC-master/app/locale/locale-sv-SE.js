Language = {
    "Connected (encrypted) to ": "Ansluten (krypterat) till ",
    "Connected (unencrypted) to ": "Ansluten (okrypterat) till ",
    "Must set host and port": "Du måste specifiera en host och port",
    "Disconnect timeout": "Det tog för lång tid att koppla ner",
    "Password is required": "Lösenord krävs",
    "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "Tvingar 'Clipping mode' eftersom skrollning inte stödjs av IE i fullskärm",
    "Connecting...": "Ansluter...",
    "Disconnecting...": "Kopplar ner...",
    "Disconnected": "Frånkopplad",
};
